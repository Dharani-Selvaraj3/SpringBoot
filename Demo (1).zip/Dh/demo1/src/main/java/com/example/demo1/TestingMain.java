package com.example.demo1;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingMain {
	
	public static void main(String[] args)
	{
		System.out.println("Started...");
	}
}